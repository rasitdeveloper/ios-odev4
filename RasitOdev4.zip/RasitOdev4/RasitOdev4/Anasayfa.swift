//
//  ViewController.swift
//  RasitOdev4
//
//  Created by Buket İşler on 1.10.2022.
//

import UIKit

class Anasayfa: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnA(_ sender: Any) {
    }
    
    @IBAction func btnX(_ sender: Any) {
    }
}

