//
//  SayfaY.swift
//  RasitOdev4
//
//  Created by Buket İşler on 1.10.2022.
//

import UIKit

class SayfaY: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnAnasayfa(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
    }
    
}
