//
//  SayfaA.swift
//  RasitOdev4
//
//  Created by Buket İşler on 1.10.2022.
//

import UIKit

class SayfaA: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnB(_ sender: Any) {
    }
    

}
